#!/bin/bash
set -u -e
echo ""
echo ""
echo "Building"
javac Assignment3.java
echo ""
echo ""
echo "Running"
java Assignment3
