#!/bin/bash
set -u -e
echo ""
echo ""
echo ""
echo "Building"
javac Assignment1.java
echo ""
echo ""
echo ""
java Assignment1
