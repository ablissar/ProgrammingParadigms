#!/bin/bash
set -u -e
echo ""
echo ""
echo "Building"
javac Car.java
